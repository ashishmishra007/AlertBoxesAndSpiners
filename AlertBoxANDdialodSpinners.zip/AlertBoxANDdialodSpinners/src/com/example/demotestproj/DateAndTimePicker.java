package com.example.demotestproj;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.DatePicker;
import android.widget.TimePicker;

import com.example.demotestproj.R;

public class DateAndTimePicker extends Activity {

	protected void onCreate(android.os.Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.picker);
		findViewById(R.id.button_date).setOnClickListener(
				new OnClickListener() {
					@Override
					public void onClick(View v) {
						showDialog(1);
					}
				});
		findViewById(R.id.button_time).setOnClickListener(
				new OnClickListener() {
					@Override
					public void onClick(View v) {
						showDialog(2);
					}
				});
	};

	OnDateSetListener ondate = new OnDateSetListener() {
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			Builder builder = new AlertDialog.Builder(DateAndTimePicker.this);
			builder.setMessage("Selected date  : " + year + "/"
					+ (++monthOfYear) + "/" + dayOfMonth);
			builder.setPositiveButton("OK", null);
			builder.show();
		}
	};

	OnTimeSetListener onTimeSetListener = new OnTimeSetListener() {

		@Override
		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
			Builder builder = new AlertDialog.Builder(DateAndTimePicker.this);
			builder.setMessage("Selected Time  : " + hourOfDay + ":" + minute);
			builder.setPositiveButton("OK", null);
			builder.show();
		}
	};

	@Override
	protected Dialog onCreateDialog(int id) {
		Calendar calendar = Calendar.getInstance();
		switch (id) {
		case 1:
			DatePickerDialog datePicker = new DatePickerDialog(this, ondate,
					calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
					calendar.get(Calendar.DAY_OF_MONTH));
			return datePicker;
		case 2:
			TimePickerDialog timePicker = new TimePickerDialog(this,
					onTimeSetListener, calendar.get(Calendar.HOUR_OF_DAY),
					calendar.get(Calendar.MINUTE), false);
			return timePicker;
		}
		return super.onCreateDialog(id);
	}
}
