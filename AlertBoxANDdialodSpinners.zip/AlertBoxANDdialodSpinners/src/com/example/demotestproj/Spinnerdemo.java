package com.example.demotestproj;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class Spinnerdemo extends Activity {
	private Spinner sp1,sp2;
	String[] androidBooks = 
		{
			"Malaysia",
			"United States",
			"Indonesia",
			"France",
			"Italy",
			"Singapore",
			"New Zealand",
			"India",
			"Pro Android Games - Vladimir Silva",
		};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.spinnerdemo);
		sp1 = (Spinner)findViewById(R.id.spinner1); 
		sp2 = (Spinner)findViewById(R.id.spinner2); 
		
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, androidBooks);
			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			sp2.setAdapter(dataAdapter);
		
			sp2.setAdapter(dataAdapter);
	        sp2.setOnItemSelectedListener(new OnItemSelectedListener() {

				public void onItemSelected(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					int item = sp2.getSelectedItemPosition();
					Toast.makeText(getBaseContext(), 
							"You have selected the country: " + androidBooks[item], 
							Toast.LENGTH_SHORT).show();
				}

				public void onNothingSelected(AdapterView<?> arg0) {
				}
	        	
	        });
			
			
        ArrayAdapter<String> adapter = 
        		new ArrayAdapter<String> (this, 
            			android.R.layout.simple_spinner_item,androidBooks);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp1.setAdapter(adapter);
        sp1.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				int item = sp1.getSelectedItemPosition();
				Toast.makeText(getBaseContext(), 
						"You have selected the country: " + androidBooks[item], 
						Toast.LENGTH_SHORT).show();
			}

			public void onNothingSelected(AdapterView<?> arg0) {
			}
        	
        });
	}

}
